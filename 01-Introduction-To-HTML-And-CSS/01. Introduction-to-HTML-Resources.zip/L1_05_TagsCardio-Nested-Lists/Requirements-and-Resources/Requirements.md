# 05 - Tags Cardio - Nested Lists
------

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS).

## Constraints
 * Change the document **title** to *Nested Lists*
 * Use **h2** tag for heading
 * Use different types for **ordered** and **unordered** lists
 * See the screenshot and use different type attribute as **circle**, **disc** etc. 