# 06 - Tags Cardio - Table
------

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS).

## Constraints
 * Change the document **title** to *Checkout tablе*
 * Use **h2** tag for heading
 * Use **table** tag to create a table
 * Use **tr** tag for rows
 * Use **th** and **td** tags for columns 
 * Use **span** tag with value **checked** for checked items
