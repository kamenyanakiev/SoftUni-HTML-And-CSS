﻿# 07 - Tags Cardio - DataTable
------

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS).

## Constraints
 * Change the document **title** to *Simple Data Table*
 * Use **h2** tag for heading
 * Use **table**, **thead**, and **tbody** tags to create table 
 * Use **tr** tag for rows
 * Use **th** and **td** tags for columns